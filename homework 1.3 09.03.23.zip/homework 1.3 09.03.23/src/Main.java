public class Main {
    public static void main(String[] args) {

        System.out.println(5 % 4);
        System.out.println(15 % 3);
        boolean y1 = 2 % 2 == 0;
        System.out.println("true-ciotnoe,false-neciotnoe: " + y1);

        boolean y2 = 7 % 2 == 0;
        System.out.println("true-ciotnoe,false-neciotnoe: " + y2);

        boolean y3 = 13 % 2 == 0;
        System.out.println("true-ciotnoe,false-neciotnoe: " + y3);

        boolean y4 = 14 % 2 == 0;
        System.out.println("true-ciotnoe,false-neciotnoe: " + y4);

        int f1 = 15 % 10;
        System.out.println(f1);
    }
}