import java.util.MissingFormatArgumentException;

public class Main {
    public static void main(String[] args) {
        int Mihail= 21;
        int Kostya= 10;
        int summa = Mihail+Kostya;
        System.out.println("vot cto vishlo:" + summa);


        int minus = Mihail - Kostya;
        System.out.println("vot cto vishlo:" + minus);

        int umnojenie = Mihail * Kostya;
        System.out.println("vot cto vishlo:" + umnojenie);

        int delenie = Mihail / Kostya;
        System.out.println("vot cto vishlo:" + delenie);

        int delenieost = Mihail % Kostya;
        System.out.println("vot cto vishlo s ostatkom :" + delenieost);

    }
}