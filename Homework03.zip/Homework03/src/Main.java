public class Main {
    public static void main(String[] args) {
        System.out.println("Bykov Alexei Ivanovici");
        System.out.println("Age 28");
        System.out.println("Height 170");
        System.out.println();
        System.out.println("Bulat Mihail Andreevici");
        System.out.println("Age 20");
        System.out.println("Heigh 168");
        System.out.println();
        System.out.println("Alexeev Sergei Petrovici");
        System.out.println("Age 17");
        System.out.println("Heigh 175");
        System.out.println();
        System.out.println("Afanasiev Nikolai Fiodorovici");
        System.out.println("Age35");
        System.out.println("Heigh 183");
        System.out.println();
        System.out.println();
        System.out.printf("%.2f ,%.2f ,%.2f", 3.222, 4.333, 5.444);
        System.out.println();
        System.out.print(" ");
        System.out.print("-");
        System.out.print("-");
        System.out.println("-");
        System.out.print("I");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.println("I");
        System.out.print(" ");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        
    }
}