public class Main {
    public static final char Auto ='A';
    public static final char Bus ='B';
    public static void main(String[] args) {
        boolean Vasboolean=true ;
        byte Vasbyte= 12;
        short Vasshort= 183;
        int Vasint= 12345678;
        long Vaslong= 1l;
        float Vasfloat= 1.2f;
        double Vasdouble= 1.23;
        char Vaschar= Auto;
        System.out.println("Vasboolean:"+ Vasboolean);
        System.out.println("Vasbyte:"+ Vasbyte);
        System.out.println("Vasshort:"+ Vasshort);
        System.out.println("Vasint:"+ Vasint);
        System.out.println("Vaslong:"+ Vaslong);
        System.out.println("Vasfloat:"+ Vasfloat);
        System.out.println("Vasdouble:"+ Vasdouble);
        System.out.println("Vaschar:"+ Vaschar);
        Vasint = Vasint + 3;
        System.out.println( "Vasintizm:"+ Vasint);
        Vasboolean = false;
        System.out.println("Vasbooleanizm:"+ Vasboolean);
        Vaschar = Bus;
        System.out.println("Vascharizm:"+ Vaschar);
    }
}